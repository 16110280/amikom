<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Membuat Template Website Bootstrap</title>
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/style.css" rel="stylesheet">

  </head>
  <body>
    <div class="container">
    <div class="row">
        <div class="col-md-12 header" id="site-header">
            <header>
    <h1 class="title-site">FAUZAN ADY NUGRAHA</h1>
    <p class="description">INI ADALAH CONTOH MEMBUAT WEBSITE DENGAN BOOTSTRAP</p>
</header>
<nav class="menus">
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Tentang Saya</a></li>
        <li><a href="#">Portfolio</a></li>
    </ul>

</nav>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 articles" id="site-content">
           <article class="posts">
    <h2 class="title-post">Selamat Datang di Website Saya</h2>
    <div class="meta-post">
        <span><em class="glyphicon glyphicon-user"></em> Yogyakarta</span>
        <span><em class="glyphicon glyphicon-time"></em> 19 Mei 2018</span>
    </div>
    <div class="content">
        <p>Website ini berisikan tentang UNIVERSITAS AMIKOM YOGYAKARTA.Dimulai dari profil Amikom Yogyakarta sampai dengan bagaimana bisa Amikom yang semula perguruan tinggi swasta menjadi perguruan tinggi negeri.</p>
        <p>Mengapa saya menceritakan tentang Amikom? Karena saya adalah mahasiswa Amikom.Karena banyak orang yang penasaran mengenai Universitas Amikom jadi pada kesempatan kali ini saya akan sharing tentang Universitas Amikom.</p>
        <p>Semua yang ada pada artikel ini adalah karangan saya semata karena beberapa artikel pada website ini saya buat menurut pendapat saya pribadi,dan beberapa saya ambil dari sumber yang ada.</p>
    </div>
</article>
        </div>
        <div class="col-md-4 sidebar" id="site-sidebar">
            <aside class="widgets">
            <form>
  <div class="form-group">
    <label for="email">Email</label>
    <input type="email" class="form-control" id="email" placeholder="Email">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" id="password" placeholder="Password">
  </div>
  <div class="checkbox">
    <label>
      <input type="checkbox"> Ingat saya?
    </label>
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>
    <h3 class="widget-title">Latest Posts</h3>
    <ul>
        <li><a href="#">PROFIL AMIKOM</a></li>
        <li><a href="#">SEJARAH AMIKOM</a></li>
        <li><a href="#">FASILITAS AMIKOM</a></li>
        <li><a href="#">CARA PENDAFTARAN AMIKOM</a></li>
        <li><a href="#">AMIKOM MENJADI UNIVERSITAS</a></li>
    </ul>
</aside>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 footer" id="site-footer">
            <footer class=”copyright”><p>>>>>FAUZAN ADY NUGRAHA<<<<</p></footer>
            <a class="btn btn-success btn-sm" href="#" role="button" data-toggle="modal" data-target="#contohModal">DOWNLOAD</a>
<div class="modal fade" id="contohModal" tabindex="-1" role="dialog" aria-labelledby="contohModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="titleModal">Fauzan Ady Nugraha</h4>
      </div>
      <div class="modal-body">
        ingin mendownload website ini?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>
        </div>
    </div>
</div><div class="container">
    <div class="row">
        <div class="col-md-12 header" id="site-header">
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 articles" id="site-content">
        </div>
        <div class="col-md-4 sidebar" id="site-sidebar">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 footer" id="site-footer">
        </div>
    </div>
</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="assets/jquery/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/custom.js"></script>
  </body>
</html>